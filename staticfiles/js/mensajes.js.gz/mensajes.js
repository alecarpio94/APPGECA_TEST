function error(mensaje) {
iziToast.error({
    title: 'Error',
    message: 'Fecha Invalida',
});
}

function no(men){
	iziToast.error({
		title: 'Alerta!',
		message: men,
	})
}

function fecha(men){
	iziToast.error({
		title: 'Alerta!',
		message: men,
	})
}